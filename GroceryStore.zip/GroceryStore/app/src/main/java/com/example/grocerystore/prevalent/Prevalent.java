package com.example.grocerystore.prevalent;

import com.example.grocerystore.model.Customers;

public class Prevalent {
    private Customers currentOnlineCustomer;

    public static final String customerEmail = "email";
    public static final String customerPassword = "password";
}
